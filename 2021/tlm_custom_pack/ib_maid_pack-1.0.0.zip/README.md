# 介绍

本资源包是Minecraft模组“[Touhou Little Maid（车万女仆）](https://github.com/TartaricAcid/TouhouLittleMaid)”的附属模型包，添加了来自游戏《Ib》（中文译作《恐怖美术馆》）中的两个角色模型：Ib和Mary。

GitHub页面：[https://github.com/jingjing96/TLM_Ib_maid_pack](https://github.com/jingjing96/TLM_Ib_maid_pack)

# 协议

本资源包的制作灵感来源于恐怖解谜游戏《Ib》（中文译作《恐怖美术馆》）中的相关角色（[原作官网](http://kouri.kuchinawa.com/game_01.html)；[授权中文版官网](http://www.shuizilong.com/ib/game_01.html)）。

本资源包是作者凭借个人兴趣制作，并非原作游戏的官方衍生作品，任何基于本资源包的二次创作，请在遵守原作游戏之[指导方针](http://kouri.kuchinawa.com/rule.html)的条件下进行（[中文版指导方针](http://www.shuizilong.com/ib/rule.html)）。

本资源包采用[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh)协议发布，请勿用于任何商业用途，转载请注明作者以及原作官网。

注明作者时使用以下方式均可：GitHub：@jingjing96 ，MCBBS：@京京1996 ，bilibili：@京京2016 ，MCMOD：@京京1996 。
