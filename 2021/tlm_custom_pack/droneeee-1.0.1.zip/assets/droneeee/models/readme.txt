你好！
很高兴你喜欢我的作品，该模型包采用 CC BY-NC-SA 3.0 协议发布，在遵循上述协议的情况下你可以随意使用这些模型。
请 勿 将 这 些 模 型 用 于 商 业 用 途 ！
你可以通过这些方式联系我：
QQ：672265464
邮箱（不常用）：gmg711211311@163.com

2021/1/13
goumo_g
-----------------------------------
Hi!
I am glad that you like my model. The model package is released under the CC BY-NC-SA 3.0 protocol. You can use these models as you like under the above protocol.
DO NOT USE THESE MODELS FOR COMMERCIAL PURPOSES!
Contact me:
QQ: 672265464
Email address(rarely used): gmg711211311@163.com

2021/1/13
goumo_g