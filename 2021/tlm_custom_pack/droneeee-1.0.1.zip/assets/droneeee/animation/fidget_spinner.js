var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		fan = modelMap.get("fan");
		drone = modelMap.get("drone");

		if (maid.isSitting()) {
			GlWrapper.translate(0, 0.975, 0);
		} else {
			if (fan != undefined) {fan.setRotateAngleY(ageInTicks % 360 * 0.2)};
			if (drone != undefined) {var time = (ageInTicks * 3.6) % 360; drone.setOffsetY(Math.sin(ageInTicks * 0.1) * 0.015)};
		}	
	}
})