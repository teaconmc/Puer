var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		sphere = modelMap.get("sphere");
		sphere2 = modelMap.get("sphere2");
		plant = modelMap.get("plant");

		if (sphere != undefined) {sphere.setRotateAngleY(ageInTicks % 360 * 0.01)};
		if (sphere2 != undefined) {sphere2.setRotateAngleY(ageInTicks % 360 * 0.05)};
		if (plant != undefined) {plant.setRotateAngleY(ageInTicks % 360 * 0.1)};
		if (plant != undefined) {var time = (ageInTicks * 3.6) % 360; plant.setOffsetY(Math.sin(ageInTicks * 0.06) * 0.2)};
		}
	}
)