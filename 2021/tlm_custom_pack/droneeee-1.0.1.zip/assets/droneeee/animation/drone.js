var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		fan = modelMap.get("fan");
		fan2 = modelMap.get("fan2");
		fan3 = modelMap.get("fan3");
		fan4 = modelMap.get("fan4");
		drone = modelMap.get("drone");
		speed = ageInTicks % 360;
		a1 = Math.sin((limbSwing * 0.5) * limbSwingAmount * 0.015 * Math.PI / 180);

		if (maid.isSitting()) {
			GlWrapper.translate(0, 1, 0)
		} else {
			GlWrapper.rotate(a1 * 100, 1, 0, 0)
			if (fan != undefined) {fan.setRotateAngleY(speed)}
			if (fan2 != undefined) {fan2.setRotateAngleY(speed)}
			if (fan3 != undefined) {fan3.setRotateAngleY(speed)}
			if (fan4 != undefined) {fan4.setRotateAngleY(speed)}
			if (drone != undefined) {drone.setOffsetY(Math.sin(ageInTicks * 0.1) * 0.015)}
		}
	}
})