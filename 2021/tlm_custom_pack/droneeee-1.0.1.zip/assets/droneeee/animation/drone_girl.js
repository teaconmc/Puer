var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		fan = modelMap.get("fan");
		spine1 = modelMap.get("spine1");
		spine2 = modelMap.get("spine2");
		spine3 = modelMap.get("spine3");
		spine4 = modelMap.get("spine4");
		spine5 = modelMap.get("spine5");
		spine6 = modelMap.get("spine6");
		hair2 = modelMap.get("hair2");
		hair3 = modelMap.get("hair3");
		drone = modelMap.get("drone");
		a1 = ageInTicks % 360;
		a2 = Math.sin((limbSwing * 50) * limbSwingAmount * 0.0002 * Math.PI / 180);
		a3 = Math.sin(ageInTicks * 0.08) * 0.01;
		a4 = Math.sin(ageInTicks * 0.15) * 0.01;

		if (maid.isSitting()) {
			GlWrapper.translate(0, 1.2, 0.5);
			GlWrapper.rotate(-90, 1, 0, 0);
		} else {
			GlWrapper.rotate(a2 * 80, 1, 0, 0)
			if (drone != undefined) {drone.setOffsetY(a3)}
			if (fan != undefined) {fan.setRotateAngleY(a1)}
			if (spine1 != undefined) {spine1.setRotateAngleX(a2 + a3)}
			if (spine2 != undefined) {spine2.setRotateAngleX(a2 + a3)}
			if (spine3 != undefined) {spine3.setRotateAngleX(a2 + a3)}
			if (spine4 != undefined) {spine4.setRotateAngleX(a2 + a3)}
			if (spine5 != undefined) {spine5.setRotateAngleX(a2 + a3)}
			if (spine6 != undefined) {spine6.setRotateAngleX(a2 + a3)}
			if (hair2 != undefined) {hair2.setRotateAngleX((a2 * 1.5) + a4)}
			if (hair3 != undefined) {hair3.setRotateAngleX((a2 * 1.5) + a4)}
		}
	}
})